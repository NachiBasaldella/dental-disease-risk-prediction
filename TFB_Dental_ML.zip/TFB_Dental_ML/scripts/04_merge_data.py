import pandas as pd


# ============================================================
# 1. Carga de los archivos procesados
# ============================================================

demo = pd.read_csv(
    "data_processed/demo_clean.csv"
)

caries = pd.read_csv(
    "data_processed/caries_final.csv"
)

periodontitis = pd.read_csv(
    "data_processed/periodontitis_final.csv"
)

print("Dimensiones iniciales")
print(f"DEMO: {demo.shape}")
print(f"CARIES: {caries.shape}")
print(f"PERIODONTITIS: {periodontitis.shape}")


# ============================================================
# 2. Validación de identificadores
# ============================================================

for nombre, df in {
    "DEMO": demo,
    "CARIES": caries,
    "PERIODONTITIS": periodontitis
}.items():

    duplicados = df["SEQN"].duplicated().sum()

    print(f"\nDuplicados en {nombre}: {duplicados}")

    if duplicados > 0:
        raise ValueError(
            f"El archivo {nombre} contiene SEQN duplicados."
        )


# ============================================================
# 3. Integración de los datos
# ============================================================

dataset = demo.merge(
    caries,
    on="SEQN",
    how="inner"
)

print("\nDimensiones después del merge DEMO + CARIES:")
print(dataset.shape)

dataset = dataset.merge(
    periodontitis,
    on="SEQN",
    how="inner"
)

print("\nDimensiones después del merge con PERIODONTITIS:")
print(dataset.shape)


# ============================================================
# 4. Construcción de la variable objetivo
# ============================================================

dataset["ENFERMEDAD_BUCODENTAL"] = (
    (dataset["CARIES"] == 1)
    |
    (dataset["PERIODONTITIS"] == 1)
).astype(int)


# ============================================================
# 5. Validaciones
# ============================================================

print("\nDistribución de CARIES:")
print(dataset["CARIES"].value_counts().sort_index())

print("\nDistribución de PERIODONTITIS:")
print(dataset["PERIODONTITIS"].value_counts().sort_index())

print("\nDistribución de ENFERMEDAD_BUCODENTAL:")
print(
    dataset["ENFERMEDAD_BUCODENTAL"]
    .value_counts()
    .sort_index()
)

print("\nValores faltantes:")
print(dataset.isna().sum())

duplicados = dataset["SEQN"].duplicated().sum()

print("\nDuplicados en SEQN:")
print(duplicados)

if duplicados > 0:
    raise ValueError(
        "Existen identificadores SEQN duplicados."
    )

valores = set(
    dataset["ENFERMEDAD_BUCODENTAL"]
    .unique()
)

if not valores.issubset({0, 1}):
    raise ValueError(
        "La variable ENFERMEDAD_BUCODENTAL contiene valores inválidos."
    )


# ============================================================
# 6. Vista previa
# ============================================================

print("\nPrimeras filas:")
print(dataset.head())

print("\nDimensiones finales:")
print(dataset.shape)


# ============================================================
# 7. Guardado del dataset maestro
# ============================================================

dataset.to_csv(
    "data_processed/dataset_master.csv",
    index=False
)

print(
    "\nDataset maestro guardado correctamente en:"
)

print(
    "data_processed/dataset_master.csv"
)