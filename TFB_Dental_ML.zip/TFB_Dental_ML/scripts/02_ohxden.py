import pandas as pd


# ======================
# Carga de datos
# ======================

# Archivo de dentición de NHANES 2011-2012
ohxden = pd.read_sas(
    "data_raw/variable_objetivo/OHXDEN_G.xpt"
)


# ======================
# Identificación de variables
# ======================

# Variables de condición de las superficies coronales.
# Todas terminan en "CSC".
caries_cols = [
    columna
    for columna in ohxden.columns
    if columna.endswith("CSC")
]

print("Dimensiones originales:")
print(ohxden.shape)

print("\nNúmero de variables de superficies coronales:")
print(len(caries_cols))

print("\nDistribución del estado del examen oral:")
print(
    ohxden["OHDEXSTS"]
    .value_counts(dropna=False)
    .sort_index()
)


# ======================
# Selección de exámenes completos
# ======================

# OHDEXSTS:
# 1 = Examen completo
# 2 = Examen parcial
# 3 = Examen no realizado

ohx_complete = ohxden[
    ohxden["OHDEXSTS"] == 1
].copy()

print("\nParticipantes con examen oral completo:")
print(ohx_complete.shape[0])


# ======================
# Normalización de las variables CSC
# ======================

# Las variables CSC pueden almacenarse como bytes al leer el archivo SAS.
# Se convierten a texto para poder examinar cada código.

for columna in caries_cols:
    ohx_complete[columna] = (
        ohx_complete[columna]
        .apply(
            lambda valor: (
                valor.decode("utf-8")
                if isinstance(valor, bytes)
                else valor
            )
        )
        .astype("string")
    )


# ======================
# Creación de la variable CARIES
# ======================

# Códigos de caries según la superficie:
# 0 = Caries lingual
# 1 = Caries oclusal o incisal
# 2 = Caries facial
# 3 = Caries mesial
# 4 = Caries distal

codigos_caries = set("01234")


def presenta_caries(fila):
    """
    Devuelve 1 si al menos una superficie dental presenta
    un código de caries y 0 si no se detecta caries.
    """

    for valor in fila:

        # Ignorar valores faltantes
        if pd.isna(valor):
            continue

        # Convertir el valor a texto y eliminar espacios
        valor_texto = str(valor).strip()

        # Comprobar si contiene algún código de caries
        if any(
            codigo in valor_texto
            for codigo in codigos_caries
        ):
            return 1

    return 0


ohx_complete["CARIES"] = (
    ohx_complete[caries_cols]
    .apply(presenta_caries, axis=1)
)


# ======================
# Construcción del dataset final de caries
# ======================

caries_final = ohx_complete[
    [
        "SEQN",
        "CARIES"
    ]
].copy()


# ======================
# Validaciones
# ======================

print("\nDimensiones del dataset de caries:")
print(caries_final.shape)

print("\nDistribución de CARIES:")
print(
    caries_final["CARIES"]
    .value_counts(dropna=False)
    .sort_index()
)

print("\nValores faltantes:")
print(
    caries_final
    .isnull()
    .sum()
)

print("\nDuplicados de SEQN:")
print(
    caries_final["SEQN"]
    .duplicated()
    .sum()
)

print("\nPrimeras filas:")
print(
    caries_final.head()
)


# Verificar que CARIES solo contenga 0 y 1
valores_validos = set(
    caries_final["CARIES"]
    .dropna()
    .unique()
)

if not valores_validos.issubset({0, 1}):
    raise ValueError(
        "La variable CARIES contiene valores distintos de 0 y 1."
    )

# Verificar que SEQN no tenga duplicados
if caries_final["SEQN"].duplicated().any():
    raise ValueError(
        "Se detectaron participantes duplicados en caries_final."
    )


# ======================
# Guardar dataset
# ======================

caries_final.to_csv(
    "data_processed/caries_final.csv",
    index=False
)

print("\nArchivo caries_final.csv guardado correctamente.")