import pandas as pd


# ============================================================
# 1. Carga del archivo de consumo de alcohol
# ============================================================

alq = pd.read_sas(
    "data_raw/variable_predictorias/ALQ_G.xpt"
).copy()

print("Dimensiones originales del archivo ALQ:")
print(alq.shape)


# ============================================================
# 2. Selección de las variables necesarias
# ============================================================

columnas_necesarias = [
    "SEQN",
    "ALQ101"
]

columnas_faltantes = [
    columna
    for columna in columnas_necesarias
    if columna not in alq.columns
]

if columnas_faltantes:
    raise ValueError(
        "Faltan las siguientes variables en el archivo ALQ: "
        f"{columnas_faltantes}"
    )

alcohol = alq[columnas_necesarias].copy()

print("\nDimensiones después de seleccionar las variables:")
print(alcohol.shape)


# ============================================================
# 3. Exploración inicial
# ============================================================

print("\nDistribución original de ALQ101:")

print(
    alcohol["ALQ101"]
    .value_counts(dropna=False)
    .sort_index()
)

print("\nValores faltantes antes de la limpieza:")

print(
    alcohol.isna().sum()
)


# ============================================================
# 4. Limpieza de códigos especiales
# ============================================================

# ALQ101:
# 1 = Sí
# 2 = No
# 7 = Rechazó responder
# 9 = No sabe

alcohol["ALQ101"] = alcohol["ALQ101"].replace(
    [7, 9],
    pd.NA
)


# ============================================================
# 5. Validación de códigos
# ============================================================

valores_observados = set(
    alcohol["ALQ101"]
    .dropna()
    .unique()
)

valores_validos = {
    1,
    2
}

valores_invalidos = (
    valores_observados - valores_validos
)

if valores_invalidos:
    raise ValueError(
        "ALQ101 contiene códigos no esperados: "
        f"{valores_invalidos}"
    )


# ============================================================
# 6. Construcción de la variable ALCOHOL_USE
# ============================================================

# ALQ101:
# 1 = Sí
# 2 = No
#
# Variable final:
# 1 = Consume alcohol
# 0 = No consume alcohol

alcohol["ALCOHOL_USE"] = alcohol["ALQ101"].map(
    {
        1: 1,
        2: 0
    }
).astype("Int64")


# ============================================================
# 7. Creación del archivo final
# ============================================================

alcohol_final = alcohol[
    [
        "SEQN",
        "ALCOHOL_USE"
    ]
].copy()


# ============================================================
# 8. Validaciones
# ============================================================

print("\nDistribución de ALCOHOL_USE:")

print(
    alcohol_final["ALCOHOL_USE"]
    .value_counts(dropna=False)
    .sort_index()
)

print("\nValores faltantes:")

print(
    alcohol_final.isna().sum()
)

duplicados = (
    alcohol_final["SEQN"]
    .duplicated()
    .sum()
)

print("\nIdentificadores SEQN duplicados:")
print(duplicados)

if duplicados > 0:
    raise ValueError(
        "Se encontraron identificadores SEQN duplicados."
    )

if alcohol_final["SEQN"].isna().any():
    raise ValueError(
        "La variable SEQN contiene valores faltantes."
    )

valores = set(
    alcohol_final["ALCOHOL_USE"]
    .dropna()
    .unique()
)

if not valores.issubset({0, 1}):
    raise ValueError(
        "ALCOHOL_USE contiene valores distintos de 0 y 1."
    )


# ============================================================
# 9. Vista previa
# ============================================================

print("\nPrimeras filas del archivo final:")

print(alcohol_final.head())

print("\nDimensiones finales:")

print(alcohol_final.shape)

print("\nTipos de datos:")

print(alcohol_final.dtypes)


# ============================================================
# 10. Guardado del archivo procesado
# ============================================================

alcohol_final.to_csv(
    "data_processed/alcohol_final.csv",
    index=False
)

print(
    "\nArchivo guardado correctamente en:"
)

print(
    "data_processed/alcohol_final.csv"
)