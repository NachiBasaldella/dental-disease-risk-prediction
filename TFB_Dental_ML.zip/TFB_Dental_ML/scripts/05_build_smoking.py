import pandas as pd


# ============================================================
# 1. Carga del archivo de tabaquismo
# ============================================================

smq = pd.read_sas(
    "data_raw/variable_predictorias/SMQ_G.xpt"
).copy()

print("Dimensiones originales del archivo SMQ:")
print(smq.shape)


# ============================================================
# 2. Selección de las variables necesarias
# ============================================================

columnas_necesarias = [
    "SEQN",
    "SMQ020",
    "SMQ040"
]

columnas_faltantes = [
    columna
    for columna in columnas_necesarias
    if columna not in smq.columns
]

if columnas_faltantes:
    raise ValueError(
        "Faltan las siguientes variables en el archivo SMQ: "
        f"{columnas_faltantes}"
    )

smoking = smq[columnas_necesarias].copy()

print("\nDimensiones después de seleccionar las variables:")
print(smoking.shape)


# ============================================================
# 3. Exploración inicial de las variables
# ============================================================

print("\nDistribución de SMQ020:")
print(
    smoking["SMQ020"]
    .value_counts(dropna=False)
    .sort_index()
)

print("\nDistribución de SMQ040:")
print(
    smoking["SMQ040"]
    .value_counts(dropna=False)
    .sort_index()
)

print("\nValores faltantes antes de la limpieza:")
print(
    smoking[
        ["SMQ020", "SMQ040"]
    ].isna().sum()
)


# ============================================================
# 4. Limpieza de códigos especiales
# ============================================================

# Códigos NHANES:
# 7 = Rechazó responder
# 9 = No sabe
#
# Se reemplazan por valores faltantes para evitar clasificarlos
# como categorías válidas.

smoking["SMQ020"] = smoking["SMQ020"].replace(
    [7, 9],
    pd.NA
)

smoking["SMQ040"] = smoking["SMQ040"].replace(
    [7, 9],
    pd.NA
)


# ============================================================
# 5. Construcción de la variable SMOKER_STATUS
# ============================================================

def clasificar_tabaquismo(fila):
    """
    Clasifica a cada participante según su historial
    y estado actual de tabaquismo.

    Categorías:
    - Current: fuma actualmente todos los días o algunos días.
    - Former: fumó al menos 100 cigarrillos en su vida,
      pero actualmente no fuma.
    - Never: no fumó al menos 100 cigarrillos en su vida.
    - pd.NA: información insuficiente.
    """

    smq020 = fila["SMQ020"]
    smq040 = fila["SMQ040"]

    # Si SMQ020 es faltante, no se puede determinar
    # el historial de tabaquismo.
    if pd.isna(smq020):
        return pd.NA

    # SMQ020 = 2:
    # no fumó al menos 100 cigarrillos en su vida.
    if smq020 == 2:
        return "Never"

    # SMQ020 = 1:
    # fumó al menos 100 cigarrillos en su vida.
    if smq020 == 1:

        # Si SMQ040 es faltante, no puede determinarse
        # si fuma actualmente.
        if pd.isna(smq040):
            return pd.NA

        # SMQ040 = 1: fuma todos los días
        # SMQ040 = 2: fuma algunos días
        if smq040 == 1 or smq040 == 2:
            return "Current"

        # SMQ040 = 3: actualmente no fuma
        if smq040 == 3:
            return "Former"

    return pd.NA


smoking["SMOKER_STATUS"] = smoking.apply(
    clasificar_tabaquismo,
    axis=1
)


# ============================================================
# 6. Creación del archivo final
# ============================================================

smoking_final = smoking[
    ["SEQN", "SMOKER_STATUS"]
].copy()


# ============================================================
# 7. Validaciones
# ============================================================

print("\nDistribución de SMOKER_STATUS:")
print(
    smoking_final["SMOKER_STATUS"]
    .value_counts(dropna=False)
)

print("\nValores faltantes:")
print(
    smoking_final
    .isna()
    .sum()
)

duplicados = (
    smoking_final["SEQN"]
    .duplicated()
    .sum()
)

print("\nIdentificadores SEQN duplicados:")
print(duplicados)

if duplicados > 0:
    raise ValueError(
        "Se encontraron identificadores SEQN duplicados."
    )

if smoking_final["SEQN"].isna().any():
    raise ValueError(
        "La variable SEQN contiene valores faltantes."
    )

categorias_validas = {
    "Current",
    "Former",
    "Never"
}

categorias_observadas = set(
    smoking_final["SMOKER_STATUS"]
    .dropna()
    .unique()
)

if not categorias_observadas.issubset(categorias_validas):
    raise ValueError(
        "SMOKER_STATUS contiene categorías no válidas."
    )


# ============================================================
# 8. Vista previa
# ============================================================

print("\nPrimeras filas del archivo final:")
print(smoking_final.head())

print("\nDimensiones finales:")
print(smoking_final.shape)


# ============================================================
# 9. Guardado del archivo procesado
# ============================================================

smoking_final.to_csv(
    "data_processed/smoking_final.csv",
    index=False
)

print(
    "\nArchivo guardado correctamente en: "
    "data_processed/smoking_final.csv"
)