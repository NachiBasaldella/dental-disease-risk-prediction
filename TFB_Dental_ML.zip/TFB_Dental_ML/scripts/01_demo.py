import pandas as pd

# Carga de datos


# Datos demográficos de NHANES 2011-2012
demo = pd.read_sas(
    "data_raw/variable_predictorias/DEMO_G.xpt"
)

# Selección de variables


variables_demo = [
    "SEQN",
    "RIDAGEYR",
    "RIAGENDR",
    "RIDRETH1",
    "DMDEDUC2",
    "INDFMPIR"
]

demo_clean = demo[variables_demo].copy()

# Exploración inicial


print("Dimensiones antes de la limpieza:")
print(demo_clean.shape)

print("\nDistribución original de DMDEDUC2:")
print(
    demo_clean["DMDEDUC2"]
    .value_counts(dropna=False)
    .sort_index()
)


# Limpieza de DMDEDUC2


# Códigos especiales de NHANES:
# 7 = Rechazó responder
# 9 = No sabe

filas_antes = len(demo_clean)

demo_clean = demo_clean[
    ~demo_clean["DMDEDUC2"].isin([7, 9])
].copy()

filas_eliminadas = filas_antes - len(demo_clean)

print(
    "\nFilas eliminadas por respuestas no informativas "
    f"en DMDEDUC2: {filas_eliminadas}"
)


# Validaciones


print("\nDimensiones después de la limpieza:")
print(demo_clean.shape)

print("\nDistribución final de DMDEDUC2:")
print(
    demo_clean["DMDEDUC2"]
    .value_counts(dropna=False)
    .sort_index()
)

print("\nValores faltantes:")
print(
    demo_clean
    .isnull()
    .sum()
    .sort_values(ascending=False)
)

print("\nDuplicados de SEQN:")
print(demo_clean["SEQN"].duplicated().sum())

print("\nPrimeras filas:")
print(demo_clean.head())

# Guardar dataset limpio


demo_clean.to_csv(
    "data_processed/demo_clean.csv",
    index=False
)

print("\nArchivo demo_clean.csv guardado correctamente.")