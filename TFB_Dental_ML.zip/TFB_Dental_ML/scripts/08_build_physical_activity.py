import pandas as pd


# ============================================================
# 1. Carga del archivo de actividad física
# ============================================================

paq = pd.read_sas(
    "data_raw/variable_predictorias/PAQ_G.xpt"
).copy()

print("Dimensiones originales del archivo PAQ:")
print(paq.shape)


# ============================================================
# 2. Selección de las variables necesarias
# ============================================================

columnas_necesarias = [
    "SEQN",
    "PAQ635",  # Camina o utiliza bicicleta para desplazarse
    "PAQ650",  # Realiza actividad recreativa vigorosa
    "PAQ665"   # Realiza actividad recreativa moderada
]

columnas_faltantes = [
    columna
    for columna in columnas_necesarias
    if columna not in paq.columns
]

if columnas_faltantes:
    raise ValueError(
        "Faltan las siguientes variables en el archivo PAQ: "
        f"{columnas_faltantes}"
    )

physical = paq[columnas_necesarias].copy()

print("\nDimensiones después de seleccionar las variables:")
print(physical.shape)


# ============================================================
# 3. Exploración inicial
# ============================================================

variables_actividad = [
    "PAQ635",
    "PAQ650",
    "PAQ665"
]

for variable in variables_actividad:

    print(f"\nDistribución original de {variable}:")

    print(
        physical[variable]
        .value_counts(dropna=False)
        .sort_index()
    )

print("\nValores faltantes antes de la limpieza:")
print(
    physical.isna().sum()
)


# ============================================================
# 4. Limpieza de códigos especiales
# ============================================================

# Códigos NHANES:
# 1 = Sí
# 2 = No
# 7 = Rechazó responder
# 9 = No sabe
#
# Los códigos 7 y 9 se convierten en valores faltantes.

for variable in variables_actividad:

    physical[variable] = physical[variable].replace(
        [7, 9],
        pd.NA
    )


# ============================================================
# 5. Validación de códigos
# ============================================================

for variable in variables_actividad:

    valores_observados = set(
        physical[variable]
        .dropna()
        .unique()
    )

    valores_validos = {
        1,
        2
    }

    valores_invalidos = (
        valores_observados - valores_validos
    )

    if valores_invalidos:
        raise ValueError(
            f"La variable {variable} contiene códigos "
            f"no esperados: {valores_invalidos}"
        )


# ============================================================
# 6. Construcción de la variable PHYSICALLY_ACTIVE
# ============================================================

# Criterio:
#
# PHYSICALLY_ACTIVE = 1:
# el participante respondió Sí en al menos una de las
# tres actividades analizadas.
#
# PHYSICALLY_ACTIVE = 0:
# el participante respondió No en las tres actividades.
#
# PHYSICALLY_ACTIVE = NaN:
# no respondió Sí en ninguna actividad, pero falta información
# en una o más de las tres variables. Por lo tanto, no puede
# clasificarse con seguridad como inactivo.

alguna_actividad = (
    physical[variables_actividad]
    .eq(1)
    .any(axis=1)
)

todas_son_no = (
    physical[variables_actividad]
    .eq(2)
    .all(axis=1)
)

physical["PHYSICALLY_ACTIVE"] = pd.Series(
    pd.NA,
    index=physical.index,
    dtype="Int64"
)

physical.loc[
    alguna_actividad,
    "PHYSICALLY_ACTIVE"
] = 1

physical.loc[
    todas_son_no,
    "PHYSICALLY_ACTIVE"
] = 0


# ============================================================
# 7. Creación del archivo final
# ============================================================

physical_final = physical[
    [
        "SEQN",
        "PHYSICALLY_ACTIVE"
    ]
].copy()


# ============================================================
# 8. Validaciones finales
# ============================================================

print("\nDistribución de PHYSICALLY_ACTIVE:")

print(
    physical_final["PHYSICALLY_ACTIVE"]
    .value_counts(dropna=False)
    .sort_index()
)

print("\nValores faltantes:")

print(
    physical_final.isna().sum()
)

duplicados = (
    physical_final["SEQN"]
    .duplicated()
    .sum()
)

print("\nIdentificadores SEQN duplicados:")
print(duplicados)

if duplicados > 0:
    raise ValueError(
        "Se encontraron identificadores SEQN duplicados."
    )

if physical_final["SEQN"].isna().any():
    raise ValueError(
        "La variable SEQN contiene valores faltantes."
    )

valores_observados = set(
    physical_final["PHYSICALLY_ACTIVE"]
    .dropna()
    .unique()
)

if not valores_observados.issubset({0, 1}):
    raise ValueError(
        "PHYSICALLY_ACTIVE contiene valores distintos de 0 y 1."
    )


# ============================================================
# 9. Vista previa
# ============================================================

print("\nPrimeras filas del archivo final:")
print(physical_final.head())

print("\nDimensiones finales:")
print(physical_final.shape)

print("\nTipos de datos:")
print(physical_final.dtypes)


# ============================================================
# 10. Guardado del archivo procesado
# ============================================================

physical_final.to_csv(
    "data_processed/physical_activity_final.csv",
    index=False
)

print(
    "\nArchivo guardado correctamente en: "
    "data_processed/physical_activity_final.csv"
)

#La lógica final queda
# 1 = respondió “Sí” en al menos una actividad
# 0 = respondió “No” en las tres actividades
# NaN = información insuficiente para clasificar