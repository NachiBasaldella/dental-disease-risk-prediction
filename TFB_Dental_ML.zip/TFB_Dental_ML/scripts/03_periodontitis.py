import pandas as pd


# ============================================================
# 1. Carga del archivo de examen periodontal
# ============================================================

ohxper = pd.read_sas(
    "data_raw/variable_objetivo/OHXPER_G.xpt"
).copy()

print("Dimensiones originales del archivo OHXPER:")
print(ohxper.shape)


# ============================================================
# 2. Identificación de las variables periodontales
# ============================================================

# PCL = pérdida de inserción clínica (Clinical Attachment Loss)
pcl_cols = [
    columna
    for columna in ohxper.columns
    if columna.endswith("PCL")
]

# PCD = profundidad de sondaje periodontal (Pocket Depth)
pcd_cols = [
    columna
    for columna in ohxper.columns
    if columna.endswith("PCD")
]

print("\nNúmero de variables PCL encontradas:")
print(len(pcl_cols))

print("\nNúmero de variables PCD encontradas:")
print(len(pcd_cols))

if not pcl_cols:
    raise ValueError(
        "No se encontraron variables PCL en el archivo OHXPER."
    )

if not pcd_cols:
    raise ValueError(
        "No se encontraron variables PCD en el archivo OHXPER."
    )


# ============================================================
# 3. Revisión del estado del examen periodontal
# ============================================================

print("\nDistribución del estado del examen periodontal:")
print(
    ohxper["OHDPDSTS"]
    .value_counts(dropna=False)
    .sort_index()
)

# OHDPDSTS:
# 1 = examen periodontal completo
# 2 = examen parcial
# 3 = examen no realizado
#
# Se conservan únicamente los participantes con examen completo.

ohxper = ohxper.loc[
    ohxper["OHDPDSTS"] == 1
].copy()

print("\nDimensiones después de conservar exámenes completos:")
print(ohxper.shape)


# ============================================================
# 4. Limpieza de las mediciones periodontales
# ============================================================

# En las variables PCL y PCD, el valor 99 representa una
# medición que no pudo ser registrada o evaluada.
# Se reemplaza por NaN para que no intervenga en la clasificación.

ohxper[pcl_cols] = ohxper[pcl_cols].replace(99, pd.NA)
ohxper[pcd_cols] = ohxper[pcd_cols].replace(99, pd.NA)


# ============================================================
# 5. Comprobación de disponibilidad de mediciones
# ============================================================

# Se comprueba que cada participante tenga al menos una medición
# periodontal válida entre las variables PCL y PCD.

tiene_medicion_valida = (
    ohxper[pcl_cols + pcd_cols]
    .notna()
    .any(axis=1)
)

sin_mediciones = (~tiene_medicion_valida).sum()

print("\nParticipantes sin ninguna medición periodontal válida:")
print(sin_mediciones)

# Se eliminan los participantes sin mediciones válidas para evitar
# clasificarlos incorrectamente como ausencia de periodontitis.

ohxper = ohxper.loc[
    tiene_medicion_valida
].copy()

print("\nDimensiones después de eliminar casos sin mediciones:")
print(ohxper.shape)


# ============================================================
# 6. Construcción de la variable PERIODONTITIS
# ============================================================

# Criterio simplificado:
#
# PERIODONTITIS = 1 si el participante presenta:
# - al menos una medición PCL igual o superior a 4 mm, o
# - al menos una medición PCD igual o superior a 5 mm.
#
# En caso contrario:
# PERIODONTITIS = 0.

presenta_pcl = (
    ohxper[pcl_cols]
    .ge(4)
    .any(axis=1)
)

presenta_pcd = (
    ohxper[pcd_cols]
    .ge(5)
    .any(axis=1)
)

ohxper["PERIODONTITIS"] = (
    presenta_pcl | presenta_pcd
).astype(int)


# ============================================================
# 7. Creación del archivo final
# ============================================================

periodontitis_final = ohxper[
    ["SEQN", "PERIODONTITIS"]
].copy()


# ============================================================
# 8. Validaciones
# ============================================================

print("\nDistribución de PERIODONTITIS:")
print(
    periodontitis_final["PERIODONTITIS"]
    .value_counts(dropna=False)
    .sort_index()
)

print("\nValores faltantes:")
print(
    periodontitis_final
    .isna()
    .sum()
)

duplicados = (
    periodontitis_final["SEQN"]
    .duplicated()
    .sum()
)

print("\nIdentificadores SEQN duplicados:")
print(duplicados)

if duplicados > 0:
    raise ValueError(
        "Se encontraron identificadores SEQN duplicados."
    )

valores_periodontitis = set(
    periodontitis_final["PERIODONTITIS"]
    .dropna()
    .unique()
)

if not valores_periodontitis.issubset({0, 1}):
    raise ValueError(
        "La variable PERIODONTITIS contiene valores distintos de 0 y 1."
    )

if periodontitis_final["PERIODONTITIS"].isna().any():
    raise ValueError(
        "La variable PERIODONTITIS contiene valores faltantes."
    )

if periodontitis_final["SEQN"].isna().any():
    raise ValueError(
        "La variable SEQN contiene valores faltantes."
    )


# ============================================================
# 9. Guardado del archivo procesado
# ============================================================

periodontitis_final.to_csv(
    "data_processed/periodontitis_final.csv",
    index=False
)

print("\nPrimeras filas del archivo final:")
print(periodontitis_final.head())

print("\nDimensiones finales:")
print(periodontitis_final.shape)

print(
    "\nArchivo guardado correctamente en: "
    "data_processed/periodontitis_final.csv"
)