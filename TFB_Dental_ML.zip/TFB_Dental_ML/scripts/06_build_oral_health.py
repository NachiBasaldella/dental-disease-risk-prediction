import pandas as pd


# ============================================================
# 1. Carga del archivo de salud oral
# ============================================================

ohq = pd.read_sas(
    "data_raw/variable_predictorias/OHQ_G.xpt"
).copy()

print("Dimensiones originales del archivo OHQ:")
print(ohq.shape)


# ============================================================
# 2. Selección de las variables necesarias
# ============================================================

columnas_necesarias = [
    "SEQN",
    "OHQ030",
    "OHQ845",
    "OHQ850",
    "OHQ855",
    "OHQ860"
]

columnas_faltantes = [
    columna
    for columna in columnas_necesarias
    if columna not in ohq.columns
]

if columnas_faltantes:
    raise ValueError(
        "Faltan las siguientes variables en el archivo OHQ: "
        f"{columnas_faltantes}"
    )

oral = ohq[columnas_necesarias].copy()

print("\nDimensiones después de seleccionar las variables:")
print(oral.shape)


# ============================================================
# 3. Exploración inicial
# ============================================================

for variable in columnas_necesarias[1:]:

    print(f"\nDistribución original de {variable}:")

    print(
        oral[variable]
        .value_counts(dropna=False)
        .sort_index()
    )

print("\nValores faltantes antes de la limpieza:")
print(oral.isna().sum())


# ============================================================
# 4. Limpieza de códigos especiales
# ============================================================

# OHQ030:
# 77 = Rechazó responder
# 99 = No sabe

oral["OHQ030"] = oral["OHQ030"].replace(
    [77, 99],
    pd.NA
)

# OHQ845, OHQ850, OHQ855 y OHQ860:
# 7 = Rechazó responder
# 9 = No sabe

variables_con_codigos_7_9 = [
    "OHQ845",
    "OHQ850",
    "OHQ855",
    "OHQ860"
]

for variable in variables_con_codigos_7_9:

    oral[variable] = oral[variable].replace(
        [7, 9],
        pd.NA
    )


# ============================================================
# 5. Validación de los códigos antes de recodificar
# ============================================================

codigos_validos = {
    "OHQ030": {1, 2, 3, 4, 5, 6, 7},
    "OHQ845": {1, 2, 3, 4, 5},
    "OHQ850": {1, 2},
    "OHQ855": {1, 2},
    "OHQ860": {1, 2}
}

for variable, valores_validos in codigos_validos.items():

    valores_observados = set(
        oral[variable]
        .dropna()
        .unique()
    )

    valores_invalidos = (
        valores_observados - valores_validos
    )

    if valores_invalidos:
        raise ValueError(
            f"La variable {variable} contiene códigos no esperados: "
            f"{valores_invalidos}"
        )


# ============================================================
# 6. Recodificación de variables
# ============================================================

# ------------------------------------------------------------
# 6.1 Última visita al odontólogo
# ------------------------------------------------------------

mapa_ultima_visita = {
    1: "Within 6 months",
    2: "6 months to 1 year",
    3: "1 to 2 years",
    4: "2 to 3 years",
    5: "3 to 5 years",
    6: "More than 5 years",
    7: "Never"
}

oral["OHQ030"] = oral["OHQ030"].map(
    mapa_ultima_visita
)


# ------------------------------------------------------------
# 6.2 Autopercepción de la salud oral
# ------------------------------------------------------------

mapa_salud_oral = {
    1: "Excellent",
    2: "Very good",
    3: "Good",
    4: "Fair",
    5: "Poor"
}

oral["OHQ845"] = oral["OHQ845"].map(
    mapa_salud_oral
)


# ------------------------------------------------------------
# 6.3 Variables binarias
# ------------------------------------------------------------

# En las variables originales:
# 1 = Sí
# 2 = No
#
# En el dataset procesado:
# 1 = Sí
# 0 = No

mapa_binario = {
    1: 1,
    2: 0
}

for variable in [
    "OHQ850",
    "OHQ855",
    "OHQ860"
]:

    oral[variable] = oral[variable].map(
        mapa_binario
    ).astype("Int64")


# ============================================================
# 7. Renombrado de variables
# ============================================================

oral = oral.rename(
    columns={
        "OHQ030": "LAST_DENTAL_VISIT",
        "OHQ845": "ORAL_HEALTH_RATING",
        "OHQ850": "GUM_TREATMENT",
        "OHQ855": "LOOSE_TEETH",
        "OHQ860": "BONE_LOSS"
    }
)


# ============================================================
# 8. Validaciones finales
# ============================================================

print("\nDistribución de LAST_DENTAL_VISIT:")
print(
    oral["LAST_DENTAL_VISIT"]
    .value_counts(dropna=False)
)

print("\nDistribución de ORAL_HEALTH_RATING:")
print(
    oral["ORAL_HEALTH_RATING"]
    .value_counts(dropna=False)
)

for variable in [
    "GUM_TREATMENT",
    "LOOSE_TEETH",
    "BONE_LOSS"
]:

    print(f"\nDistribución de {variable}:")

    print(
        oral[variable]
        .value_counts(dropna=False)
        .sort_index()
    )

print("\nValores faltantes después de la recodificación:")
print(oral.isna().sum())


# ============================================================
# 9. Validación de SEQN
# ============================================================

duplicados = oral["SEQN"].duplicated().sum()

print("\nIdentificadores SEQN duplicados:")
print(duplicados)

if duplicados > 0:
    raise ValueError(
        "Se encontraron identificadores SEQN duplicados."
    )

if oral["SEQN"].isna().any():
    raise ValueError(
        "La variable SEQN contiene valores faltantes."
    )


# ============================================================
# 10. Validación de variables binarias
# ============================================================

for variable in [
    "GUM_TREATMENT",
    "LOOSE_TEETH",
    "BONE_LOSS"
]:

    valores_observados = set(
        oral[variable]
        .dropna()
        .unique()
    )

    if not valores_observados.issubset({0, 1}):
        raise ValueError(
            f"La variable {variable} contiene valores "
            "distintos de 0 y 1."
        )


# ============================================================
# 11. Vista previa
# ============================================================

print("\nPrimeras filas del archivo final:")
print(oral.head())

print("\nDimensiones finales:")
print(oral.shape)

print("\nTipos de datos finales:")
print(oral.dtypes)


# ============================================================
# 12. Guardado del archivo procesado
# ============================================================

oral.to_csv(
    "data_processed/oral_health_final.csv",
    index=False
)

print(
    "\nArchivo guardado correctamente en: "
    "data_processed/oral_health_final.csv"
)