import pandas as pd


# ============================================================
# 1. Rutas de los archivos procesados
# ============================================================

rutas_datasets = {
    "master": "data_processed/dataset_master.csv",
    "smoking": "data_processed/smoking_final.csv",
    "alcohol": "data_processed/alcohol_final.csv",
    "oral": "data_processed/oral_health_final.csv",
    "physical": "data_processed/physical_activity_final.csv"
}


# ============================================================
# 2. Carga de los datasets
# ============================================================

dataset = pd.read_csv(
    rutas_datasets["master"]
).copy()

smoking = pd.read_csv(
    rutas_datasets["smoking"]
).copy()

alcohol = pd.read_csv(
    rutas_datasets["alcohol"]
).copy()

oral = pd.read_csv(
    rutas_datasets["oral"]
).copy()

physical = pd.read_csv(
    rutas_datasets["physical"]
).copy()


datasets_predictoras = {
    "smoking": smoking,
    "alcohol": alcohol,
    "oral": oral,
    "physical": physical
}


print("Dimensiones originales de los datasets:")

print(f"dataset_master: {dataset.shape}")

for nombre, dataframe in datasets_predictoras.items():
    print(f"{nombre}: {dataframe.shape}")


# ============================================================
# 3. Validación de la variable identificadora SEQN
# ============================================================

datasets_a_validar = {
    "dataset_master": dataset,
    **datasets_predictoras
}

for nombre, dataframe in datasets_a_validar.items():

    if "SEQN" not in dataframe.columns:
        raise ValueError(
            f"El dataset {nombre} no contiene la columna SEQN."
        )

    seqn_faltantes = dataframe["SEQN"].isna().sum()

    if seqn_faltantes > 0:
        raise ValueError(
            f"El dataset {nombre} contiene "
            f"{seqn_faltantes} valores faltantes en SEQN."
        )

    duplicados = dataframe["SEQN"].duplicated().sum()

    print(
        f"\nSEQN duplicados en {nombre}: "
        f"{duplicados}"
    )

    if duplicados > 0:
        raise ValueError(
            f"El dataset {nombre} contiene "
            f"{duplicados} identificadores SEQN duplicados."
        )


# ============================================================
# 4. Validación del dataset maestro
# ============================================================

columnas_master_necesarias = [
    "SEQN",
    "CARIES",
    "PERIODONTITIS",
    "ENFERMEDAD_BUCODENTAL"
]

columnas_faltantes_master = [
    columna
    for columna in columnas_master_necesarias
    if columna not in dataset.columns
]

if columnas_faltantes_master:
    raise ValueError(
        "Faltan las siguientes columnas en dataset_master.csv: "
        f"{columnas_faltantes_master}"
    )


# ============================================================
# 5. Validación de las variables predictoras
# ============================================================

columnas_esperadas = {
    "smoking": [
        "SEQN",
        "SMOKER_STATUS"
    ],
    "alcohol": [
        "SEQN",
        "ALCOHOL_USE"
    ],
    "oral": [
        "SEQN",
        "LAST_DENTAL_VISIT",
        "ORAL_HEALTH_RATING",
        "GUM_TREATMENT",
        "LOOSE_TEETH",
        "BONE_LOSS"
    ],
    "physical": [
        "SEQN",
        "PHYSICALLY_ACTIVE"
    ]
}

for nombre, columnas in columnas_esperadas.items():

    dataframe = datasets_predictoras[nombre]

    columnas_faltantes = [
        columna
        for columna in columnas
        if columna not in dataframe.columns
    ]

    if columnas_faltantes:
        raise ValueError(
            f"Faltan columnas en el dataset {nombre}: "
            f"{columnas_faltantes}"
        )


# ============================================================
# 6. Comprobación de solapamiento de columnas
# ============================================================

# Antes de cada merge se verifica que no existan columnas
# repetidas distintas de SEQN.

for nombre, dataframe in datasets_predictoras.items():

    columnas_repetidas = (
        set(dataset.columns)
        .intersection(dataframe.columns)
        - {"SEQN"}
    )

    if columnas_repetidas:
        raise ValueError(
            f"El dataset {nombre} contiene columnas que ya existen "
            f"en el dataset principal: {columnas_repetidas}"
        )


# ============================================================
# 7. Incorporación de las variables predictoras
# ============================================================

filas_iniciales = len(dataset)

for nombre, dataframe in datasets_predictoras.items():

    dataset = dataset.merge(
        dataframe,
        on="SEQN",
        how="left",
        validate="one_to_one"
    )

    print(
        f"\nDimensiones después de añadir {nombre}: "
        f"{dataset.shape}"
    )

    if len(dataset) != filas_iniciales:
        raise ValueError(
            f"El merge con {nombre} modificó el número "
            "de participantes del dataset maestro."
        )


# ============================================================
# 8. Validación de la variable objetivo
# ============================================================

valores_objetivo = set(
    dataset["ENFERMEDAD_BUCODENTAL"]
    .dropna()
    .unique()
)

if not valores_objetivo.issubset({0, 1}):
    raise ValueError(
        "ENFERMEDAD_BUCODENTAL contiene valores "
        "distintos de 0 y 1."
    )

if dataset["ENFERMEDAD_BUCODENTAL"].isna().any():
    raise ValueError(
        "ENFERMEDAD_BUCODENTAL contiene valores faltantes."
    )


# Verificación de coherencia con CARIES y PERIODONTITIS

objetivo_recalculado = (
    (dataset["CARIES"] == 1)
    |
    (dataset["PERIODONTITIS"] == 1)
).astype(int)

inconsistencias_objetivo = (
    dataset["ENFERMEDAD_BUCODENTAL"]
    != objetivo_recalculado
).sum()

print(
    "\nInconsistencias en la variable objetivo:"
)

print(inconsistencias_objetivo)

if inconsistencias_objetivo > 0:
    raise ValueError(
        "ENFERMEDAD_BUCODENTAL no coincide con la combinación "
        "de CARIES y PERIODONTITIS."
    )


# ============================================================
# 9. Validación de variables binarias
# ============================================================

variables_binarias = [
    "CARIES",
    "PERIODONTITIS",
    "ENFERMEDAD_BUCODENTAL",
    "ALCOHOL_USE",
    "GUM_TREATMENT",
    "LOOSE_TEETH",
    "BONE_LOSS",
    "PHYSICALLY_ACTIVE"
]

for variable in variables_binarias:

    valores_observados = set(
        dataset[variable]
        .dropna()
        .unique()
    )

    if not valores_observados.issubset({0, 1}):
        raise ValueError(
            f"La variable {variable} contiene valores "
            f"distintos de 0 y 1: {valores_observados}"
        )


# ============================================================
# 10. Conversión de variables binarias a tipo entero nullable
# ============================================================

# Se utiliza Int64 para conservar valores faltantes
# sin convertir las columnas a float.

for variable in variables_binarias:

    dataset[variable] = (
        dataset[variable]
        .astype("Int64")
    )


# ============================================================
# 11. Validación final de duplicados
# ============================================================

duplicados_finales = (
    dataset["SEQN"]
    .duplicated()
    .sum()
)

print("\nSEQN duplicados en el dataset final:")
print(duplicados_finales)

if duplicados_finales > 0:
    raise ValueError(
        "El dataset final contiene identificadores "
        "SEQN duplicados."
    )


# ============================================================
# 12. Resumen del dataset final
# ============================================================

print("\nDimensiones finales:")
print(dataset.shape)

print("\nNúmero total de participantes:")
print(len(dataset))

print("\nNúmero total de variables:")
print(dataset.shape[1])

print("\nColumnas del dataset final:")

for columna in dataset.columns:
    print(f"- {columna}")


print("\nValores faltantes por variable:")

missing_values = (
    dataset.isna()
    .sum()
    .sort_values(ascending=False)
)

print(missing_values)


print("\nPorcentaje de valores faltantes por variable:")

missing_percentage = (
    dataset.isna()
    .mean()
    .mul(100)
    .round(2)
    .sort_values(ascending=False)
)

print(missing_percentage)


print("\nDistribución de la variable objetivo:")

print(
    dataset["ENFERMEDAD_BUCODENTAL"]
    .value_counts(dropna=False)
    .sort_index()
)


print("\nDistribución porcentual de la variable objetivo:")

print(
    dataset["ENFERMEDAD_BUCODENTAL"]
    .value_counts(
        normalize=True,
        dropna=False
    )
    .mul(100)
    .round(2)
    .sort_index()
)


print("\nTipos de datos:")

print(dataset.dtypes)


print("\nPrimeras filas del dataset final:")

print(dataset.head())


# ============================================================
# 13. Guardado del dataset final
# ============================================================

ruta_salida = (
    "data_processed/dataset_final.csv"
)

dataset.to_csv(
    ruta_salida,
    index=False
)

print(
    "\nDataset final guardado correctamente en:"
)

print(ruta_salida)